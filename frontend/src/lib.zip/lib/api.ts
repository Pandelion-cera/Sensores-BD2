import axios, { AxiosInstance, AxiosRequestConfig } from 'axios'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

class ApiClient {
  private client: AxiosInstance

  constructor() {
    this.client = axios.create({
      baseURL: `${API_URL}/api`,
      headers: {
        'Content-Type': 'application/json',
      },
    })

    // Request interceptor to add auth token
    this.client.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('token')
        if (token) {
          config.headers.Authorization = `Bearer ${token}`
        }
        return config
      },
      (error) => Promise.reject(error)
    )

    // Response interceptor to handle errors
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          // Unauthorized - clear token and redirect to login
          localStorage.removeItem('token')
          localStorage.removeItem('user')
          window.location.href = '/login'
        }
        return Promise.reject(error)
      }
    )
  }

  // Auth endpoints
  async register(data: { nombre_completo: string; email: string; password: string }) {
    const response = await this.client.post('/auth/register', data)
    return response.data
  }

  async login(data: { email: string; password: string }) {
    const response = await this.client.post('/auth/login', data)
    return response.data
  }

  async logout(sessionId: string) {
    const response = await this.client.post(`/auth/logout?session_id=${sessionId}`)
    return response.data
  }

  async getCurrentUser() {
    const response = await this.client.get('/auth/me')
    return response.data
  }

  // Sensor endpoints
  async getSensors(params?: { pais?: string; ciudad?: string; estado?: string }) {
    // Filtrar parámetros vacíos
    const cleanParams = params 
      ? Object.fromEntries(
          Object.entries(params).filter(([_, value]) => value !== '' && value !== null && value !== undefined)
        )
      : {}
    
    const response = await this.client.get('/sensors', { params: cleanParams })
    return response.data
  }

  async getSensor(id: string) {
    const response = await this.client.get(`/sensors/${id}`)
    return response.data
  }

  async createSensor(data: any) {
    const response = await this.client.post('/sensors', data)
    return response.data
  }

  async updateSensor(id: string, data: any) {
    const response = await this.client.put(`/sensors/${id}`, data)
    return response.data
  }

  async deleteSensor(id: string) {
    const response = await this.client.delete(`/sensors/${id}`)
    return response.data
  }

  async getSensorStats() {
    const response = await this.client.get('/sensors/stats')
    return response.data
  }

  // Measurement endpoints
  async getSensorMeasurements(sensorId: string, params?: { start_date?: string; end_date?: string }) {
    // Filtrar parámetros vacíos
    const cleanParams = params 
      ? Object.fromEntries(
          Object.entries(params).filter(([_, value]) => value !== '' && value !== null && value !== undefined)
        )
      : {}
    
    const response = await this.client.get(`/measurements/sensor/${sensorId}`, { params: cleanParams })
    return response.data
  }

  async getLocationMeasurements(pais: string, ciudad: string, params?: { start_date?: string; end_date?: string }) {
    // Filtrar parámetros vacíos
    const allParams = { pais, ciudad, ...params }
    const cleanParams = Object.fromEntries(
      Object.entries(allParams).filter(([_, value]) => value !== '' && value !== null && value !== undefined)
    )
    
    const response = await this.client.get('/measurements/location', { params: cleanParams })
    return response.data
  }

  async getLocationStats(pais: string, ciudad: string, params?: { start_date?: string; end_date?: string }) {
    // Filtrar parámetros vacíos
    const allParams = { pais, ciudad, ...params }
    const cleanParams = Object.fromEntries(
      Object.entries(allParams).filter(([_, value]) => value !== '' && value !== null && value !== undefined)
    )
    
    const response = await this.client.get('/measurements/stats', { params: cleanParams })
    return response.data
  }

  // Process endpoints
  async getProcesses() {
    const response = await this.client.get('/processes')
    return response.data
  }

  async getProcess(id: string) {
    const response = await this.client.get(`/processes/${id}`)
    return response.data
  }

  async requestProcess(data: { process_id: string; parametros: any }) {
    const response = await this.client.post('/processes/requests', data)
    return response.data
  }

  async getUserProcessRequests(userId: string) {
    const response = await this.client.get(`/processes/requests/user/${userId}`)
    return response.data
  }

  async getExecution(requestId: string) {
    const response = await this.client.get(`/processes/executions/${requestId}`)
    return response.data
  }

  async executeProcess(requestId: string) {
    const response = await this.client.post(`/processes/requests/${requestId}/execute`)
    return response.data
  }

  // Invoice endpoints
  async getMyInvoices() {
    const response = await this.client.get('/invoices')
    return response.data
  }

  async getInvoice(id: string) {
    const response = await this.client.get(`/invoices/${id}`)
    return response.data
  }

  async payInvoice(id: string, data: { monto: number; metodo: string }) {
    const response = await this.client.post(`/invoices/${id}/pay`, data)
    return response.data
  }

  async getMyAccount() {
    const response = await this.client.get('/invoices/account/me')
    return response.data
  }

  // Alert endpoints
  async getAlerts(params?: { estado?: string; sensor_id?: string }) {
    // Filtrar parámetros vacíos
    const cleanParams = params 
      ? Object.fromEntries(
          Object.entries(params).filter(([_, value]) => value !== '' && value !== null && value !== undefined)
        )
      : {}
    
    const response = await this.client.get('/alerts', { params: cleanParams })
    return response.data
  }

  async getActiveAlerts() {
    const response = await this.client.get('/alerts/active')
    return response.data
  }

  async resolveAlert(id: string) {
    const response = await this.client.patch(`/alerts/${id}/resolve`)
    return response.data
  }

  async acknowledgeAlert(id: string) {
    const response = await this.client.patch(`/alerts/${id}/acknowledge`)
    return response.data
  }

  // Message endpoints
  async sendMessage(data: { recipient_type: string; recipient_id: string; content: string }) {
    const response = await this.client.post('/messages', data)
    return response.data
  }

  async getMyMessages() {
    const response = await this.client.get('/messages')
    return response.data
  }

  async getGroupMessages(groupId: string) {
    const response = await this.client.get(`/messages/groups/${groupId}`)
    return response.data
  }

  // User endpoints
  async getUserAccount(userId: string) {
    const response = await this.client.get(`/users/${userId}/account`)
    return response.data
  }
}

export const api = new ApiClient()

